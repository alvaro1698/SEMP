/*
 * antSisTask.h
 *
 *  Created on: Dec 18, 2023
 *      Author: alvaromontesano
 */

#ifndef INC_ANTSISTASK_H_
#define INC_ANTSISTASK_H_

int valueSA();
void antiSisFunction(void *argument);


#endif /* INC_ANTSISTASK_H_ */
