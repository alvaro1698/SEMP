#include "cmsis_os.h"
#include <stdio.h>
#include "stm32f4xx_hal.h"

void printExternalFunction(void *argument)
{
  uint32_t count = 0;
  const char* name = osThreadGetName(osThreadGetId());
  for(;;)
  {
    osDelay(500);
	printf("%s: %ld\n", name, count);
	count++;
  }
}
