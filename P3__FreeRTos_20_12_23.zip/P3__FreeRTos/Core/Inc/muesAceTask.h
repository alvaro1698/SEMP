/*
 * muesAceTask.h
 *
 *  Created on: Dec 19, 2023
 *      Author: alvaromontesano
 */

#ifndef INC_MUESACETASK_H_
#define INC_MUESACETASK_H_

#include "fsm.h"
#include <stdint.h>

static int Sistema_Activo (fsm_t* this);
static int Sistema_No_Activo (fsm_t* this);
static void funcion_muestreo (fsm_t* this);
static void funcion_terminar (fsm_t* this);
static int empieza_muestras (fsm_t* this);
static void funcion_comparar_calculo (fsm_t* this);
static int muestras_cumplidas (fsm_t* this);
static void funcion_calculo (fsm_t* this);
int returnDeltaAce();
int returnMuestrasAce();
void muesAceFunction(void *argument);

#endif /* INC_MUESACETASK_H_ */
