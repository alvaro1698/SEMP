/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for nothingTask */
osThreadId_t nothingTaskHandle;
const osThreadAttr_t nothingTask_attributes = {
  .name = "nothingTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for ledSisTask */
osThreadId_t ledSisTaskHandle;
const osThreadAttr_t ledSisTask_attributes = {
  .name = "ledSisTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for muesAceTask */
osThreadId_t muesAceTaskHandle;
const osThreadAttr_t muesAceTask_attributes = {
  .name = "muesAceTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for muesMagTask */
osThreadId_t muesMagTaskHandle;
const osThreadAttr_t muesMagTask_attributes = {
  .name = "muesMagTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow5,
};
/* Definitions for movAceTask */
osThreadId_t movAceTaskHandle;
const osThreadAttr_t movAceTask_attributes = {
  .name = "movAceTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for movMagTask */
osThreadId_t movMagTaskHandle;
const osThreadAttr_t movMagTask_attributes = {
  .name = "movMagTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for antSisTask */
osThreadId_t antSisTaskHandle;
const osThreadAttr_t antSisTask_attributes = {
  .name = "antSisTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for deltaMagQueue */
osMessageQueueId_t deltaMagQueueHandle;
const osMessageQueueAttr_t deltaMagQueue_attributes = {
  .name = "deltaMagQueue"
};
/* Definitions for i2cMutex */
osMutexId_t i2cMutexHandle;
const osMutexAttr_t i2cMutex_attributes = {
  .name = "i2cMutex"
};
/* Definitions for buttonSem */
osSemaphoreId_t buttonSemHandle;
const osSemaphoreAttr_t buttonSem_attributes = {
  .name = "buttonSem"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void nothingFunction(void *argument);
extern void ledSisFunction(void *argument);
extern void muesAceFunction(void *argument);
extern void muesMagFunction(void *argument);
extern void movFunction(void *argument);
extern void antSisFunction(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName);

/* USER CODE BEGIN 1 */
/* Functions needed when configGENERATE_RUN_TIME_STATS is on */
__weak void configureTimerForRunTimeStats(void)
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
	DWT->CYCCNT = 0;
}

__weak unsigned long getRunTimeCounterValue(void)
{
return DWT->CYCCNT;
}
/* USER CODE END 1 */

/* USER CODE BEGIN 4 */
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName)
{
   /* Run time stack overflow checking is performed if
   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2. This hook function is
   called if a stack overflow is detected. */
}
/* USER CODE END 4 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of i2cMutex */
  i2cMutexHandle = osMutexNew(&i2cMutex_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of buttonSem */
  buttonSemHandle = osSemaphoreNew(1, 1, &buttonSem_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of deltaMagQueue */
  deltaMagQueueHandle = osMessageQueueNew (32, sizeof(uint32_t), &deltaMagQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of nothingTask */
  nothingTaskHandle = osThreadNew(nothingFunction, NULL, &nothingTask_attributes);

  /* creation of ledSisTask */
  ledSisTaskHandle = osThreadNew(ledSisFunction, NULL, &ledSisTask_attributes);

  /* creation of muesAceTask */
  muesAceTaskHandle = osThreadNew(muesAceFunction, NULL, &muesAceTask_attributes);

  /* creation of muesMagTask */
  muesMagTaskHandle = osThreadNew(muesMagFunction, NULL, &muesMagTask_attributes);

  /* creation of movAceTask */
  movAceTaskHandle = osThreadNew(movFunction, NULL, &movAceTask_attributes);

  /* creation of movMagTask */
  movMagTaskHandle = osThreadNew(movFunction, NULL, &movMagTask_attributes);

  /* creation of antSisTask */
  antSisTaskHandle = osThreadNew(antSisFunction, NULL, &antSisTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_nothingFunction */
/**
  * @brief  Function implementing the nothingTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_nothingFunction */
void nothingFunction(void *argument)
{
  /* USER CODE BEGIN nothingFunction */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END nothingFunction */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

